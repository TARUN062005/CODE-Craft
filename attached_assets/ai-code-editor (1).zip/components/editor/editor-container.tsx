"use client"

import { useState, useEffect } from "react"
import { EditorHeader } from "./editor-header"
import { CodeEditor } from "./code-editor"
import { FileExplorer } from "./file-explorer"
import { Terminal } from "./terminal"
import { ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CollaboratorsPanel } from "./collaborators-panel"
import { useLocalStorage } from "@/hooks/use-local-storage"
import { FileActions } from "./file-actions"
import { OutputPanel } from "./output-panel"
import { toast } from "@/components/ui/use-toast"
import { getLanguageFromFileName } from "@/lib/utils"

interface EditorContainerProps {
  projectId: string
}

export function EditorContainer({ projectId }: EditorContainerProps) {
  const [selectedFile, setSelectedFile] = useState("index.js")
  const [isChatOpen, setIsChatOpen] = useLocalStorage("isChatOpen", true)
  const [isTerminalOpen, setIsTerminalOpen] = useLocalStorage("isTerminalOpen", false)
  const [activeTab, setActiveTab] = useLocalStorage("activeTab", "files")
  const [editorTheme, setEditorTheme] = useLocalStorage("editorTheme", "dark")
  const [output, setOutput] = useState("")
  const [initialized, setInitialized] = useState(false)

  // Mock project data
  const project = {
    id: projectId,
    name: "React Todo App",
  }

  // Mock files data
  const [files, setFiles] = useState([
    { id: "1", name: "index.js", content: 'console.log("Hello World!");' },
    { id: "2", name: "styles.css", content: "body { font-family: sans-serif; }" },
    {
      id: "3",
      name: "app.js",
      content:
        'import React from "react";\n\nfunction App() {\n  return <div>Hello React</div>;\n}\n\nexport default App;',
    },
    {
      id: "4",
      name: "utils.js",
      content: "export function formatDate(date) {\n  return new Date(date).toLocaleDateString();\n}",
    },
    {
      id: "5",
      name: "api.js",
      content:
        'export async function fetchData() {\n  const response = await fetch("https://api.example.com/data");\n  return response.json();\n}',
    },
  ])

  // Initialize only once
  useEffect(() => {
    if (initialized) return
    setInitialized(true)
  }, [initialized])

  const currentFile = files.find((file) => file.name === selectedFile) || files[0]

  const addFile = (fileName: string) => {
    const languageInfo = getLanguageFromFileName(fileName)
    if (!languageInfo) {
      toast({
        title: "Error",
        description: "Invalid file type. Please use .html, .css, or .js extension",
        variant: "destructive",
      })
      return
    }

    const newId = (Math.max(...files.map((f) => Number.parseInt(f.id))) + 1).toString()
    const newFile = {
      id: newId,
      name: fileName,
      content: languageInfo.template || "",
    }
    setFiles([...files, newFile])
    setSelectedFile(fileName)
    toast({
      title: "File Created",
      description: `${fileName} has been created.`,
    })
  }

  const runCode = () => {
    // Simulate running the code and getting the output
    setOutput("Running code...")
    setTimeout(() => {
      setOutput("Code executed successfully!")
    }, 2000)
  }

  const updateCurrentFile = (content: string) => {
    setFiles((prevFiles) => {
      return prevFiles.map((file) => {
        if (file.id === currentFile.id) {
          return { ...file, content: content }
        }
        return file
      })
    })
  }

  return (
    <div className="flex h-screen flex-col bg-slate-950">
      <EditorHeader
        project={project}
        fileName={currentFile.name}
        onToggleChat={() => setIsChatOpen(!isChatOpen)}
        onToggleTerminal={() => setIsTerminalOpen(!isTerminalOpen)}
        theme={editorTheme}
        onChangeTheme={setEditorTheme}
        onSave={runCode}
      />
      <ResizablePanelGroup direction="horizontal" className="flex-1">
        <ResizablePanel defaultSize={20} minSize={15} maxSize={30} className="border-r border-slate-800">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
            <TabsList className="grid h-10 w-full grid-cols-2 bg-slate-900">
              <TabsTrigger value="files" className="data-[state=active]:bg-slate-800 data-[state=active]:text-white">
                Files
              </TabsTrigger>
              <TabsTrigger
                value="collaborators"
                className="data-[state=active]:bg-slate-800 data-[state=active]:text-white"
              >
                Collaborators
              </TabsTrigger>
            </TabsList>
            <TabsContent value="files" className="h-[calc(100%-2.5rem)] p-0">
              <FileExplorer files={files} selectedFile={selectedFile} onSelectFile={setSelectedFile}>
                <FileActions onAddFile={addFile} />
              </FileExplorer>
            </TabsContent>
            <TabsContent value="collaborators" className="h-[calc(100%-2.5rem)] p-0">
              <CollaboratorsPanel projectId={projectId} />
            </TabsContent>
          </Tabs>
        </ResizablePanel>

        <ResizablePanel defaultSize={isChatOpen ? 55 : 80} className="flex flex-col">
          <CodeEditor
            content={currentFile.content}
            language={currentFile.name.endsWith(".js") ? "javascript" : "css"}
            onChange={updateCurrentFile}
          />
          {isTerminalOpen && <Terminal />}
          <OutputPanel output={output} />
        </ResizablePanel>

        {isChatOpen && (
          <ResizablePanel defaultSize={25} minSize={20} maxSize={40} className="border-l border-slate-800">
            <CollaboratorsPanel projectId={projectId} />
          </ResizablePanel>
        )}
      </ResizablePanelGroup>
    </div>
  )
}
