"use client"

import { useState } from "react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { Icons } from "@/components/icons"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function Terminal() {
  const [output] = useState([
    "> npm start",
    "Starting development server...",
    "Compiled successfully!",
    "",
    "You can now view your app in the browser.",
    "",
    "  Local:            http://localhost:3000",
    "  On Your Network:  http://192.168.1.5:3000",
    "",
    "Note that the development build is not optimized.",
    "To create a production build, use npm run build.",
    "",
    "webpack compiled successfully",
  ])

  return (
    <div className="h-64 border-t border-slate-800 bg-slate-950">
      <div className="flex h-8 items-center justify-between bg-slate-900 px-4">
        <Tabs defaultValue="terminal" className="w-full">
          <TabsList className="grid h-7 w-48 grid-cols-2 bg-slate-800">
            <TabsTrigger value="terminal" className="text-xs data-[state=active]:bg-slate-700">
              Terminal
            </TabsTrigger>
            <TabsTrigger value="problems" className="text-xs data-[state=active]:bg-slate-700">
              Problems
            </TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-6 w-6 text-slate-400 hover:text-slate-200">
            <Icons.plus className="h-3 w-3" />
          </Button>
          <Button variant="ghost" size="icon" className="h-6 w-6 text-slate-400 hover:text-slate-200">
            <Icons.trash className="h-3 w-3" />
          </Button>
        </div>
      </div>
      <ScrollArea className="h-[calc(100%-2rem)] p-4">
        <pre className="font-mono text-xs text-emerald-400">{output.join("\n")}</pre>
      </ScrollArea>
    </div>
  )
}
