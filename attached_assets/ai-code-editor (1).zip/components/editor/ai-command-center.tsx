"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Icons } from "@/components/icons"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"

interface AICommandCenterProps {
  isOpen: boolean
  onClose: () => void
}

export function AICommandCenter({ isOpen, onClose }: AICommandCenterProps) {
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<any[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Hello! I'm your AI coding assistant. How can I help you today?",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ])
  const [activeTab, setActiveTab] = useState("chat")
  const [isProcessing, setIsProcessing] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = async () => {
    if (!message.trim()) return

    // Add user message
    const userMessage = {
      id: Date.now().toString(),
      role: "user",
      content: message,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages((prev) => [...prev, userMessage])
    setMessage("")
    setIsProcessing(true)

    // Simulate AI response
    setTimeout(() => {
      let response = ""

      if (message.toLowerCase().includes("help")) {
        response =
          "I can help you with coding questions, debugging, and providing suggestions. What specific help do you need?"
      } else if (message.toLowerCase().includes("error")) {
        response =
          "I can help debug that error. Can you share the specific error message or code snippet that's causing the issue?"
      } else if (message.toLowerCase().includes("example")) {
        response =
          "Here's an example of a React component:\n\n```jsx\nimport React, { useState } from 'react';\n\nfunction Counter() {\n  const [count, setCount] = useState(0);\n\n  return (\n    <div>\n      <p>Count: {count}</p>\n      <button onClick={() => setCount(count + 1)}>Increment</button>\n    </div>\n  );\n}\n\nexport default Counter;\n```"
      } else {
        response = "I understand. How can I assist you further with your code?"
      }

      const aiMessage = {
        id: Date.now().toString() + "-ai",
        role: "assistant",
        content: response,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }

      setMessages((prev) => [...prev, aiMessage])
      setIsProcessing(false)
    }, 1000)
  }

  const formatCodeBlocks = (content: string) => {
    if (!content.includes("```")) return content

    const parts = content.split("```")
    return (
      <>
        {parts.map((part, i) =>
          i % 2 === 0 ? (
            <span key={i}>{part}</span>
          ) : (
            <pre key={i} className="my-2 rounded-md bg-muted p-3 font-mono text-xs">
              <div className="mb-1 flex items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  {part.includes("\n") ? part.split("\n")[0] : "code"}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={() => {
                    const code = part.includes("\n") ? part.split("\n").slice(1).join("\n") : part
                    navigator.clipboard.writeText(code)
                  }}
                >
                  <Icons.copy className="h-3.5 w-3.5" />
                  <span className="sr-only">Copy code</span>
                </Button>
              </div>
              {part.includes("\n") ? part.split("\n").slice(1).join("\n") : part}
            </pre>
          ),
        )}
      </>
    )
  }

  if (!isOpen) {
    return (
      <Button
        className={cn(
          "fixed bottom-6 right-6 z-50 h-12 w-12 rounded-full shadow-lg",
          isProcessing ? "bg-amber-500 hover:bg-amber-600" : "bg-primary hover:bg-primary/90",
        )}
        onClick={onClose}
      >
        {isProcessing ? <Icons.spinner className="h-5 w-5 animate-spin" /> : <Icons.cpu className="h-5 w-5" />}
        <span className="sr-only">AI Assistant</span>
      </Button>
    )
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 w-80 rounded-lg border bg-background shadow-xl sm:w-96">
      <div className="flex items-center justify-between border-b p-3">
        <div className="flex items-center gap-2">
          <div className="rounded-full bg-primary/10 p-1">
            <Icons.cpu className="h-4 w-4 text-primary" />
          </div>
          <span className="font-medium">AI Assistant</span>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose}>
          <Icons.x className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="border-b">
          <TabsList className="w-full justify-start rounded-none border-b bg-transparent p-0">
            <TabsTrigger
              value="chat"
              className="rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none"
            >
              Chat
            </TabsTrigger>
            <TabsTrigger
              value="suggestions"
              className="rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none"
            >
              Suggestions
            </TabsTrigger>
            <TabsTrigger
              value="docs"
              className="rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none"
            >
              Docs
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="chat" className="h-80 p-0">
          <ScrollArea className="h-64 px-4 py-2">
            <div className="space-y-4">
              {messages.map((msg) => (
                <div key={msg.id} className={cn("flex gap-2", msg.role === "user" ? "flex-row-reverse" : "flex-row")}>
                  <Avatar className="h-8 w-8 flex-shrink-0">
                    {msg.role === "user" ? (
                      <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
                    ) : (
                      <AvatarImage src="/placeholder.svg?height=32&width=32" alt="AI" />
                    )}
                    <AvatarFallback>{msg.role === "user" ? "U" : "AI"}</AvatarFallback>
                  </Avatar>
                  <div
                    className={cn(
                      "rounded-lg px-3 py-2 text-sm",
                      msg.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted",
                    )}
                  >
                    <div className="mb-1 flex items-center gap-2">
                      <span className="text-xs font-medium">{msg.role === "user" ? "You" : "AI Assistant"}</span>
                      <span className="text-xs text-muted-foreground">{msg.timestamp}</span>
                    </div>
                    <div className="text-sm">{formatCodeBlocks(msg.content)}</div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          <div className="flex items-center gap-2 border-t p-3">
            <Input
              placeholder="Ask AI for help..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  handleSendMessage()
                }
              }}
              className="flex-1"
            />
            <Button
              size="icon"
              className="h-8 w-8 shrink-0"
              onClick={handleSendMessage}
              disabled={isProcessing || !message.trim()}
            >
              {isProcessing ? (
                <Icons.spinner className="h-4 w-4 animate-spin" />
              ) : (
                <Icons.arrowUp className="h-4 w-4" />
              )}
              <span className="sr-only">Send</span>
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="suggestions" className="h-80 p-0">
          <ScrollArea className="h-80 p-4">
            <div className="space-y-4">
              <div className="rounded-lg border bg-muted/50 p-3">
                <div className="mb-2 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icons.lightbulb className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm font-medium">Suggestion</span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    Performance
                  </Badge>
                </div>
                <p className="text-sm">
                  Consider using <code>useMemo</code> for expensive calculations to improve performance.
                </p>
                <div className="mt-2 flex justify-end">
                  <Button variant="ghost" size="sm" className="h-7 text-xs">
                    Apply
                  </Button>
                </div>
              </div>

              <div className="rounded-lg border bg-muted/50 p-3">
                <div className="mb-2 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icons.lightbulb className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm font-medium">Suggestion</span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    Best Practice
                  </Badge>
                </div>
                <p className="text-sm">Add proper error handling to your async function with try/catch blocks.</p>
                <div className="mt-2 flex justify-end">
                  <Button variant="ghost" size="sm" className="h-7 text-xs">
                    Apply
                  </Button>
                </div>
              </div>

              <div className="rounded-lg border bg-muted/50 p-3">
                <div className="mb-2 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icons.lightbulb className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm font-medium">Suggestion</span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    Accessibility
                  </Badge>
                </div>
                <p className="text-sm">Add aria-label to improve accessibility for screen readers.</p>
                <div className="mt-2 flex justify-end">
                  <Button variant="ghost" size="sm" className="h-7 text-xs">
                    Apply
                  </Button>
                </div>
              </div>
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="docs" className="h-80 p-0">
          <ScrollArea className="h-80 p-4">
            <div className="space-y-4">
              <div>
                <h3 className="mb-2 text-sm font-medium">React Hooks</h3>
                <div className="space-y-2">
                  <div className="rounded-lg border p-3">
                    <div className="flex items-center gap-2">
                      <Icons.fileText className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium">useState</span>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      A Hook that lets you add React state to function components.
                    </p>
                  </div>
                  <div className="rounded-lg border p-3">
                    <div className="flex items-center gap-2">
                      <Icons.fileText className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium">useEffect</span>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      A Hook that lets you perform side effects in function components.
                    </p>
                  </div>
                  <div className="rounded-lg border p-3">
                    <div className="flex items-center gap-2">
                      <Icons.fileText className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium">useContext</span>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      A Hook that lets you subscribe to React context without introducing nesting.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  )
}
