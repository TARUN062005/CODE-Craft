"use client"

import type React from "react"

import { useState } from "react"

interface CodeEditorProps {
  content: string
  language: string
  onChange: (content: string) => void
}

export function CodeEditor({ content, language, onChange }: CodeEditorProps) {
  const [cursorPosition, setCursorPosition] = useState({ line: 1, column: 1 })

  // Handle tab key
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Tab") {
      e.preventDefault()
      const target = e.target as HTMLTextAreaElement
      const start = target.selectionStart
      const end = target.selectionEnd

      // Insert 2 spaces for tab
      const newValue = target.value.substring(0, start) + "  " + target.value.substring(end)

      // Update the value
      onChange(newValue)

      // This is executed after React updates the input value
      setTimeout(() => {
        target.selectionStart = target.selectionEnd = start + 2
      }, 0)
    }
  }

  // Update cursor position
  const updateCursorPosition = (
    e: React.MouseEvent<HTMLTextAreaElement> | React.KeyboardEvent<HTMLTextAreaElement>,
  ) => {
    const target = e.target as HTMLTextAreaElement
    const cursorPos = target.selectionStart
    const textBeforeCursor = target.value.substring(0, cursorPos)
    const lines = textBeforeCursor.split("\n")

    setCursorPosition({
      line: lines.length,
      column: lines[lines.length - 1].length + 1,
    })
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 relative">
        <textarea
          value={content}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => {
            handleKeyDown(e)
            updateCursorPosition(e)
          }}
          onClick={updateCursorPosition}
          className="w-full h-full p-4 font-mono text-sm resize-none outline-none bg-slate-900 text-slate-200"
          spellCheck="false"
        />
      </div>
      <div className="h-6 bg-slate-800 text-slate-400 text-xs px-4 flex items-center justify-between">
        <div>
          {language.toUpperCase()} | Line: {cursorPosition.line}, Column: {cursorPosition.column}
        </div>
        <div>Spaces: 2 | UTF-8</div>
      </div>
    </div>
  )
}
