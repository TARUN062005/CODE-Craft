"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Icons } from "@/components/icons"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface CollaborationChatProps {
  projectId: string
  onClose: () => void
}

export function CollaborationChat({ projectId, onClose }: CollaborationChatProps) {
  const [message, setMessage] = useState("")
  const [activeTab, setActiveTab] = useState("team")
  const [messages, setMessages] = useState<any[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Mock collaborators data
  const collaborators = [
    {
      id: "1",
      name: "John Doe",
      email: "john.doe@example.com",
      role: "owner",
      status: "online",
      avatar: "/placeholder.svg?height=32&width=32",
      color: "#4CAF50",
    },
    {
      id: "2",
      name: "Jane Smith",
      email: "jane.smith@example.com",
      role: "editor",
      status: "online",
      avatar: "/placeholder.svg?height=32&width=32",
      color: "#2196F3",
    },
    {
      id: "3",
      name: "Bob Johnson",
      email: "bob.johnson@example.com",
      role: "viewer",
      status: "offline",
      avatar: "/placeholder.svg?height=32&width=32",
      color: "#9C27B0",
    },
  ]

  useEffect(() => {
    // Add initial messages based on active tab
    if (activeTab === "team") {
      setMessages([
        {
          id: "welcome",
          sender: "System",
          content: "Welcome to the team chat! You can collaborate with your team members here.",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          avatar: "/placeholder.svg?height=32&width=32",
          isSystem: true,
        },
      ])
    } else if (activeTab === "ai") {
      setMessages([
        {
          id: "welcome",
          sender: "AI Assistant",
          content: "Hello! I'm your AI coding assistant. How can I help you today?",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          avatar: "/placeholder.svg?height=32&width=32",
          isAI: true,
        },
      ])
    }
  }, [activeTab])

  const handleSendMessage = async () => {
    if (!message.trim()) return

    const userMessage = {
      id: Date.now().toString(),
      sender: "You",
      content: message,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      avatar: "/placeholder.svg?height=32&width=32",
    }

    setMessages((prev) => [...prev, userMessage])
    setMessage("")

    if (activeTab === "ai") {
      // Simulate AI response
      setTimeout(() => {
        const aiMessage = {
          id: Date.now().toString() + "-ai",
          sender: "AI Assistant",
          content: getAIResponse(message),
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          avatar: "/placeholder.svg?height=32&width=32",
          isAI: true,
        }
        setMessages((prev) => [...prev, aiMessage])
      }, 1000)
    } else {
      // Simulate team member response
      setTimeout(() => {
        const randomCollaborator = collaborators[Math.floor(Math.random() * collaborators.length)]
        const teamMessage = {
          id: Date.now().toString() + "-team",
          sender: randomCollaborator.name,
          content: "Thanks for your message! I'll take a look at that.",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          avatar: randomCollaborator.avatar,
        }
        setMessages((prev) => [...prev, teamMessage])
      }, 2000)
    }
  }

  // Simple AI response generator
  const getAIResponse = (userMessage: string) => {
    const message = userMessage.toLowerCase()

    if (message.includes("help") || message.includes("how")) {
      return "I'd be happy to help! Could you provide more details about what you're trying to accomplish?"
    } else if (message.includes("error") || message.includes("bug")) {
      return "Let's debug this issue. Can you share the error message or the problematic code?"
    } else if (message.includes("feature") || message.includes("implement")) {
      return "That sounds like an interesting feature! Have you considered using a specific library or approach for this?"
    } else if (message.includes("code") || message.includes("example")) {
      return "Here's a simple example:\n```js\nfunction greet(name) {\n  return `Hello, ${name}!`;\n}\n\nconsole.log(greet('Developer'));\n```"
    } else {
      return "I understand. Is there anything specific about your code you'd like me to help with?"
    }
  }

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const formatCodeBlocks = (content: string) => {
    if (!content.includes("```")) return content

    const parts = content.split("```")
    return (
      <>
        {parts.map((part, i) =>
          i % 2 === 0 ? (
            <span key={i}>{part}</span>
          ) : (
            <pre key={i} className="my-2 rounded-md bg-slate-950 p-3 font-mono text-xs text-slate-200">
              <div className="mb-1 flex items-center justify-between">
                <span className="text-xs text-slate-400">{part.includes("\n") ? part.split("\n")[0] : "code"}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 text-slate-400 hover:text-slate-200"
                  onClick={() => {
                    const code = part.includes("\n") ? part.split("\n").slice(1).join("\n") : part
                    navigator.clipboard.writeText(code)
                  }}
                >
                  <Icons.copy className="h-3 w-3" />
                  <span className="sr-only">Copy code</span>
                </Button>
              </div>
              {part.includes("\n") ? part.split("\n").slice(1).join("\n") : part}
            </pre>
          ),
        )}
      </>
    )
  }

  return (
    <Card className="fixed bottom-20 right-6 z-50 w-80 shadow-xl sm:w-96">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-md font-medium">{activeTab === "team" ? "Team Chat" : "AI Assistant"}</CardTitle>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
          <Icons.x className="h-4 w-4" />
        </Button>
      </CardHeader>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="border-b px-4">
          <TabsList className="grid h-9 w-full grid-cols-2">
            <TabsTrigger value="team">Team</TabsTrigger>
            <TabsTrigger value="ai">AI Assistant</TabsTrigger>
          </TabsList>
        </div>
        <CardContent className="p-0">
          <ScrollArea className="h-80 px-4 py-2">
            <div className="space-y-4">
              {messages.map((msg) => (
                <div key={msg.id} className="flex gap-3">
                  <Avatar className="h-8 w-8 flex-shrink-0">
                    <AvatarImage src={msg.avatar} alt={msg.sender} />
                    <AvatarFallback
                      className={`${msg.isAI ? "bg-emerald-700" : msg.isSystem ? "bg-blue-700" : "bg-slate-700"} text-white`}
                    >
                      {msg.sender.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-slate-200">{msg.sender}</span>
                      <span className="text-xs text-slate-400">{msg.timestamp}</span>
                      {msg.isAI && (
                        <Badge
                          variant="outline"
                          className="border-emerald-800 bg-emerald-900/30 text-xs text-emerald-400"
                        >
                          AI
                        </Badge>
                      )}
                      {msg.isSystem && (
                        <Badge variant="outline" className="border-blue-800 bg-blue-900/30 text-xs text-blue-400">
                          System
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-slate-300">{formatCodeBlocks(msg.content)}</div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          <div className="border-t border-slate-800 p-4">
            <div className="flex gap-2">
              <Input
                placeholder={`Message ${activeTab === "team" ? "team" : "AI assistant"}...`}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault()
                    handleSendMessage()
                  }
                }}
                className="flex-1 bg-slate-800 text-slate-200 placeholder:text-slate-500"
              />
              <Button
                size="icon"
                onClick={handleSendMessage}
                className="bg-emerald-600 text-white hover:bg-emerald-700"
              >
                <Icons.arrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Tabs>
    </Card>
  )
}
