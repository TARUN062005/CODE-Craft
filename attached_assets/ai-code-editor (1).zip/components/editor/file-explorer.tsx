"use client"

// Revert to the original working version
export function FileExplorer({ files, selectedFile, onSelectFile, children }) {
  return (
    <div className="flex h-full flex-col bg-slate-900">
      <div className="flex items-center justify-between border-b border-slate-800 p-4">
        <h3 className="font-medium text-slate-200">Files</h3>
      </div>
      <div className="flex-1 overflow-auto p-4">
        <div className="space-y-1">
          {files.map((file) => (
            <div
              key={file.id}
              className={`flex cursor-pointer items-center justify-between rounded-md px-2 py-1 ${
                selectedFile === file.name
                  ? "bg-slate-800 text-white"
                  : "text-slate-400 hover:bg-slate-800 hover:text-white"
              }`}
              onClick={() => onSelectFile(file.name)}
            >
              <span className="text-sm">{file.name}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="border-t border-slate-800 p-4">{children}</div>
    </div>
  )
}
