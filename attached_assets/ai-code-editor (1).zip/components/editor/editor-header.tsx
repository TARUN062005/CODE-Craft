"use client"

import { useState, memo } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Icons } from "@/components/icons"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useTheme } from "next-themes"

interface EditorHeaderProps {
  projectName: string
  fileName: string
  onSave: () => void
  onToggleAI: () => void
  onToggleCollaboration: () => void
}

// Using memo to prevent unnecessary re-renders
const EditorHeader = memo(function EditorHeader({
  projectName,
  fileName,
  onSave,
  onToggleAI,
  onToggleCollaboration,
}: EditorHeaderProps) {
  const router = useRouter()
  const { theme, setTheme } = useTheme()
  const [isRunning, setIsRunning] = useState(false)

  const handleRun = () => {
    setIsRunning(true)
    onSave()
    setTimeout(() => setIsRunning(false), 1000)
  }

  return (
    <div className="flex h-12 items-center justify-between border-b px-4">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={() => router.push("/dashboard")} className="h-8 w-8">
          <Icons.chevronLeft className="h-4 w-4" />
          <span className="sr-only">Back to Dashboard</span>
        </Button>

        <div className="flex items-center gap-1.5">
          <span className="font-medium">{projectName}</span>
          {fileName && (
            <>
              <Icons.chevronRight className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">{fileName}</span>
            </>
          )}
        </div>
      </div>

      <TooltipProvider>
        <div className="flex items-center gap-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onSave}>
                <Icons.save className="h-4 w-4" />
                <span className="sr-only">Save</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Save (Ctrl+S)</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant={isRunning ? "default" : "ghost"}
                size="icon"
                className="h-8 w-8"
                onClick={handleRun}
                disabled={isRunning}
              >
                {isRunning ? <Icons.spinner className="h-4 w-4 animate-spin" /> : <Icons.play className="h-4 w-4" />}
                <span className="sr-only">Run</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Run Code</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onToggleAI}>
                <Icons.cpu className="h-4 w-4" />
                <span className="sr-only">AI Assistant</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>AI Assistant</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onToggleCollaboration}>
                <Icons.users className="h-4 w-4" />
                <span className="sr-only">Collaboration</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Collaboration</p>
            </TooltipContent>
          </Tooltip>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <Icons.settings className="h-4 w-4" />
                <span className="sr-only">Settings</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setTheme(theme === "light" ? "dark" : "light")}>
                {theme === "light" ? <Icons.moon className="mr-2 h-4 w-4" /> : <Icons.sun className="mr-2 h-4 w-4" />}
                <span>{theme === "light" ? "Dark Theme" : "Light Theme"}</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Icons.settings className="mr-2 h-4 w-4" />
                <span>Editor Settings</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Icons.keyboard className="mr-2 h-4 w-4" />
                <span>Keyboard Shortcuts</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </TooltipProvider>
    </div>
  )
})

export { EditorHeader }
