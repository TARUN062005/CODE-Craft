"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Icons } from "@/components/icons"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { CollaborationChat } from "./collaboration-chat"

interface AIFabProps {
  projectId: string
}

export function AIFab({ projectId }: AIFabProps) {
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  const toggleChat = () => {
    if (isProcessing) return

    setIsProcessing(true)
    setTimeout(() => {
      setIsChatOpen(!isChatOpen)
      setIsProcessing(false)
    }, 300)
  }

  return (
    <>
      <TooltipProvider>
        <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                size="icon"
                className={`h-12 w-12 rounded-full shadow-lg ${
                  isProcessing ? "bg-amber-500 hover:bg-amber-600" : "bg-emerald-600 hover:bg-emerald-700"
                }`}
                onClick={toggleChat}
              >
                {isProcessing ? (
                  <Icons.spinner className="h-5 w-5 animate-spin" />
                ) : isChatOpen ? (
                  <Icons.x className="h-5 w-5" />
                ) : (
                  <Icons.messageSquare className="h-5 w-5" />
                )}
                <span className="sr-only">{isChatOpen ? "Close Chat" : "Open Chat"}</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent side="left">
              <p>{isChatOpen ? "Close Chat" : "Open Chat"}</p>
            </TooltipContent>
          </Tooltip>
        </div>
      </TooltipProvider>

      {isChatOpen && <CollaborationChat projectId={projectId} onClose={() => setIsChatOpen(false)} />}
    </>
  )
}
