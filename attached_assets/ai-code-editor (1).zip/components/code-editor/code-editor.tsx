"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Undo, Redo, Trash2, Upload, Download, Moon, SunMedium, Save, FolderPlus, FileText, Folder } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useLocalStorage } from "@/hooks/use-local-storage"
import { toast } from "@/hooks/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const getLanguageFromFileName = (fileName: string) => {
  const extension = fileName.split(".").pop()?.toLowerCase()
  switch (extension) {
    case "html":
      return { name: "HTML", template: "<!-- Write your HTML here -->\n<div>\n  <h1>Hello World!</h1>\n</div>" }
    case "css":
      return { name: "CSS", template: "/* Write your CSS here */\nbody {\n  color: blue;\n}" }
    case "js":
      return { name: "JavaScript", template: '// Write your JavaScript here\nconsole.log("Hello World!");' }
    case "py":
      return { name: "Python", template: '# Write your Python here\nprint("Hello World!")' }
    case "java":
      return {
        name: "Java",
        template:
          'public class Main {\n  public static void main(String[] args) {\n    System.out.println("Hello World!");\n  }\n}',
      }
    case "cpp":
      return {
        name: "C++",
        template: '#include <iostream>\n\nint main() {\n  std::cout << "Hello World!" << std::endl;\n  return 0;\n}',
      }
    default:
      return null
  }
}

interface FileData {
  id: string
  name: string
  language: string
  content: string
  history: string[]
  historyIndex: number
  parentId: string | null
}

interface FolderData {
  id: string
  name: string
  parentId: string | null
}

const CodeEditor = () => {
  const [files, setFiles] = useState<FileData[]>([
    {
      id: "1",
      name: "index.html",
      language: "html",
      content: getLanguageFromFileName("index.html")?.template || "",
      history: [getLanguageFromFileName("index.html")?.template || ""],
      historyIndex: 0,
      parentId: null,
    },
  ])
  const [folders, setFolders] = useState<FolderData[]>([
    {
      id: "root",
      name: "root",
      parentId: null,
    },
  ])
  const [activeFile, setActiveFile] = useState("1")
  const [preview, setPreview] = useState("")
  const [error, setError] = useState("")
  const [theme, setTheme] = useLocalStorage("codeEditorTheme", "dark")
  const [newFileName, setNewFileName] = useState("")
  const [newFolderName, setNewFolderName] = useState("")
  const [autoSave, setAutoSave] = useState(true)
  const [lastSaved, setLastSaved] = useState(new Date())
  const [isPreviewFullscreen, setIsPreviewFullscreen] = useState(false)
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null)
  const [output, setOutput] = useState("")

  const themes = {
    light: {
      bg: "bg-gradient-to-br from-blue-50 to-gray-100",
      text: "text-gray-800",
      primary: "bg-white/80 backdrop-blur-xl",
      secondary: "bg-blue-50/80",
      accent: "text-blue-600",
      border: "border-blue-200",
      editor: "bg-white/90",
      button: "bg-blue-100 hover:bg-blue-200 text-blue-700 shadow-lg hover:shadow-xl transition-all duration-300",
      activeTab: "bg-white text-blue-900 border-blue-300 shadow-md",
      inactiveTab: "text-gray-600 hover:text-gray-900 hover:bg-white/50",
      preview: "bg-white/90 backdrop-blur-md",
    },
    dark: {
      bg: "bg-gradient-to-br from-gray-900 to-slate-900",
      text: "text-gray-100",
      primary: "bg-gray-800/80 backdrop-blur-xl",
      secondary: "bg-slate-900/50",
      accent: "text-blue-400",
      border: "border-slate-700",
      editor: "bg-gray-900/90",
      button:
        "bg-slate-700 hover:bg-slate-600 text-gray-100 shadow-lg shadow-blue-500/20 hover:shadow-xl hover:shadow-blue-500/30 transition-all duration-300",
      activeTab: "bg-gray-800 text-blue-100 border-slate-600 shadow-lg shadow-blue-500/20",
      inactiveTab: "text-gray-400 hover:text-gray-200 hover:bg-gray-800/50",
      preview: "bg-gray-800/90 backdrop-blur-md",
    },
  }

  const currentTheme = themes[theme as keyof typeof themes]

  // Undo/Redo operations
  const undo = () => {
    const currentFile = getCurrentFile()
    if (!currentFile || currentFile.historyIndex <= 0) return

    setFiles(
      files.map((f) => {
        if (f.id === activeFile) {
          const newContent = f.history[f.historyIndex - 1]
          return {
            ...f,
            content: newContent,
            historyIndex: f.historyIndex - 1,
          }
        }
        return f
      }),
    )
  }

  const redo = () => {
    const currentFile = getCurrentFile()
    if (!currentFile || currentFile.historyIndex >= currentFile.history.length - 1) return

    setFiles(
      files.map((f) => {
        if (f.id === activeFile) {
          const newContent = f.history[f.historyIndex + 1]
          return {
            ...f,
            content: newContent,
            historyIndex: f.historyIndex + 1,
          }
        }
        return f
      }),
    )
  }

  // File upload handler
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e: ProgressEvent<FileReader>) => {
      const content = e.target?.result as string
      if (content) {
        const languageInfo = getLanguageFromFileName(file.name)

        if (!languageInfo) {
          setError("Invalid file type. Please upload .html, .css, .js, .py, .java, or .cpp files")
          return
        }

        const newId = Date.now().toString()
        const newFile = {
          id: newId,
          name: file.name,
          language: languageInfo.name.toLowerCase(),
          content: content,
          history: [content],
          historyIndex: 0,
          parentId: currentFolderId,
        }

        setFiles([...files, newFile])
        setActiveFile(newId)
        setError("")

        if (languageInfo.name.toLowerCase() === "html") {
          setPreview(content)
        }
      }
    }
    reader.readAsText(file)
  }

  const exportFile = () => {
    const currentFile = getCurrentFile()
    if (!currentFile) return

    const blob = new Blob([currentFile.content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = currentFile.name
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  // Auto-save functionality
  useEffect(() => {
    if (autoSave) {
      const saveTimer = setInterval(() => {
        const currentFile = getCurrentFile()
        if (currentFile) {
          localStorage.setItem(`editor_${currentFile.id}`, JSON.stringify(currentFile))
          setLastSaved(new Date())
        }
      }, 30000)
      return () => clearInterval(saveTimer)
    }
  }, [autoSave, files, activeFile])

  // File operations
  const getCurrentFile = useCallback(() => files.find((f) => f.id === activeFile), [files, activeFile])

  const updateCurrentFile = (newContent: string, addToHistory = true) => {
    setFiles(
      files.map((f) => {
        if (f.id === activeFile) {
          const newFile = { ...f, content: newContent }
          if (addToHistory) {
            newFile.history = [...f.history.slice(0, f.historyIndex + 1), newContent]
            newFile.historyIndex = f.historyIndex + 1
          }
          return newFile
        }
        return f
      }),
    )

    try {
      const currentFile = getCurrentFile()
      if (currentFile && currentFile.language === "html") {
        setPreview(newContent)
      } else {
        setPreview("")
      }
      setError("")
    } catch (err: any) {
      setError(err.message)
    }
  }

  // File management
  const addFile = () => {
    if (!newFileName.trim()) {
      setError("Please enter a file name")
      return
    }

    const languageInfo = getLanguageFromFileName(newFileName)
    if (!languageInfo) {
      setError("Invalid file type. Please use .html, .css, .js, .py, .java, or .cpp extension")
      return
    }

    const newId = Date.now().toString()
    const newFile = {
      id: newId,
      name: newFileName,
      language: languageInfo.name.toLowerCase(),
      content: languageInfo.template || "",
      history: [languageInfo.template || ""],
      historyIndex: 0,
      parentId: currentFolderId,
    }
    setFiles([...files, newFile])
    setActiveFile(newId)
    setNewFileName("")
    setError("")

    toast({
      title: "File Created",
      description: `${newFileName} has been created.`,
    })
  }

  const addFolder = () => {
    if (!newFolderName.trim()) {
      setError("Please enter a folder name")
      return
    }

    const newId = `folder_${Date.now()}`
    const newFolder = {
      id: newId,
      name: newFolderName,
      parentId: currentFolderId,
    }
    setFolders([...folders, newFolder])
    setNewFolderName("")

    toast({
      title: "Folder Created",
      description: `${newFolderName} has been created.`,
    })
  }

  const deleteFile = (id: string) => {
    if (files.length > 1) {
      setFiles(files.filter((f) => f.id !== id))
      if (activeFile === id) {
        const remainingFile = files.find((f) => f.id !== id)
        if (remainingFile) {
          setActiveFile(remainingFile.id)
        }
      }
    }
  }

  const deleteFolder = (id: string) => {
    // Delete the folder
    setFolders(folders.filter((f) => f.id !== id))

    // Delete all files in the folder
    setFiles(files.filter((f) => f.parentId !== id))

    // Delete all subfolders
    const subFolders = folders.filter((f) => f.parentId === id)
    subFolders.forEach((folder) => {
      deleteFolder(folder.id)
    })
  }

  const shareCode = () => {
    const currentFile = getCurrentFile()
    if (!currentFile) return

    // Create a shareable URL with the code content
    const shareableContent = encodeURIComponent(
      JSON.stringify({
        fileName: currentFile.name,
        content: currentFile.content,
      }),
    )

    const shareUrl = `${window.location.origin}/share?code=${shareableContent}`

    // Copy to clipboard
    navigator.clipboard
      .writeText(shareUrl)
      .then(() => {
        setError("")
        toast({
          title: "Link copied!",
          description: "Share link copied to clipboard",
        })
      })
      .catch(() => {
        setError("Failed to copy share link")
      })
  }

  const saveCode = () => {
    const currentFile = getCurrentFile()
    if (currentFile) {
      localStorage.setItem(`editor_${currentFile.id}`, JSON.stringify(currentFile))
      setLastSaved(new Date())

      // Execute the code and show output
      executeCode(currentFile)

      toast({
        title: "Saved!",
        description: `${currentFile.name} has been saved.`,
      })
    }
  }

  const executeCode = (file: FileData) => {
    setOutput("Executing code...")

    setTimeout(() => {
      const extension = file.name.split(".").pop()?.toLowerCase()

      switch (extension) {
        case "html":
          setPreview(file.content)
          setOutput("HTML rendered in preview panel")
          break
        case "js":
          try {
            // For JavaScript, we can actually execute it in a safe way
            const result = new Function(`
            try {
              ${file.content}
              return "Code executed successfully!";
            } catch (error) {
              return "Error: " + error.message;
            }
          `)()
            setOutput(result)
          } catch (error: any) {
            setOutput(`Error: ${error.message}`)
          }
          break
        case "py":
          setOutput("Python code execution:\n" + simulateOutput(file.content, "python"))
          break
        case "java":
          setOutput("Java code execution:\n" + simulateOutput(file.content, "java"))
          break
        case "cpp":
          setOutput("C++ code execution:\n" + simulateOutput(file.content, "cpp"))
          break
        default:
          setOutput(`No execution environment available for ${extension} files`)
      }
    }, 1000)
  }

  const simulateOutput = (code: string, language: string) => {
    // This is a simple simulation of code execution
    if (code.includes("Hello World")) {
      return "Hello World!"
    }

    if (code.includes("print") || code.includes("console.log") || code.includes("System.out.println")) {
      const match = code.match(/(print|console\.log|System\.out\.println)\s*$\s*["'](.+?)["']\s*$/)
      if (match && match[2]) {
        return match[2]
      }
    }

    return `${language} code executed successfully!`
  }

  const navigateToFolder = (folderId: string | null) => {
    setCurrentFolderId(folderId)
  }

  const getCurrentFolderName = () => {
    if (!currentFolderId) return "Root"
    const folder = folders.find((f) => f.id === currentFolderId)
    return folder ? folder.name : "Root"
  }

  const getBreadcrumbs = () => {
    const breadcrumbs = []
    let currentFolder = folders.find((f) => f.id === currentFolderId)

    while (currentFolder) {
      breadcrumbs.unshift(currentFolder)
      currentFolder = folders.find((f) => f.id === currentFolder?.parentId)
    }

    return [{ id: null, name: "Root" }, ...breadcrumbs]
  }

  return (
    <div
      className={`min-h-screen p-2 sm:p-4 ${currentTheme.bg} ${currentTheme.text} transition-colors duration-500 relative overflow-hidden`}
    >
      {/* Main toolbar */}
      <div className="flex flex-wrap gap-2 sm:gap-4 mb-4 sm:mb-6">
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            className={`${currentTheme.button} group text-sm sm:text-base`}
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
          >
            {theme === "light" ? (
              <Moon className="h-4 w-4 mr-1 sm:mr-2" />
            ) : (
              <SunMedium className="h-4 w-4 mr-1 sm:mr-2" />
            )}
            {theme === "light" ? "Dark" : "Light"}
          </Button>
          <Button
            variant="outline"
            className={`${currentTheme.button} text-sm sm:text-base`}
            onClick={() => document.getElementById("file-upload")?.click()}
          >
            <Upload className="h-4 w-4 mr-1 sm:mr-2" />
            Upload
          </Button>
          <input
            id="file-upload"
            type="file"
            accept=".html,.css,.js,.py,.java,.cpp"
            className="hidden"
            onChange={handleFileUpload}
          />
          <Button variant="outline" className={`${currentTheme.button} text-sm sm:text-base`} onClick={exportFile}>
            <Download className="h-4 w-4 mr-1 sm:mr-2" />
            Export
          </Button>
          <Button variant="outline" className={`${currentTheme.button} text-sm sm:text-base`} onClick={saveCode}>
            <Save className="h-4 w-4 mr-1 sm:mr-2" />
            Save & Run
          </Button>
        </div>
      </div>

      {/* Breadcrumb navigation */}
      <div className="flex items-center mb-4 overflow-x-auto whitespace-nowrap">
        {getBreadcrumbs().map((folder, index, array) => (
          <div key={folder.id || "root"} className="flex items-center">
            <Button
              variant="ghost"
              size="sm"
              className={`${currentTheme.text} hover:${currentTheme.accent}`}
              onClick={() => navigateToFolder(folder.id)}
            >
              {folder.name}
            </Button>
            {index < array.length - 1 && <span className="mx-1">/</span>}
          </div>
        ))}
      </div>

      {/* File and folder creation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="flex items-center gap-2">
          <Input
            type="text"
            placeholder="New file name (e.g., style.css)"
            value={newFileName}
            onChange={(e) => setNewFileName(e.target.value)}
            className={`${currentTheme.primary} ${currentTheme.text} ${currentTheme.border} text-sm sm:text-base`}
          />
          <Button variant="outline" className={`${currentTheme.button} text-sm sm:text-base`} onClick={addFile}>
            <FileText className="h-4 w-4 mr-1 sm:mr-2" />
            Add File
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <Input
            type="text"
            placeholder="New folder name"
            value={newFolderName}
            onChange={(e) => setNewFolderName(e.target.value)}
            className={`${currentTheme.primary} ${currentTheme.text} ${currentTheme.border} text-sm sm:text-base`}
          />
          <Button variant="outline" className={`${currentTheme.button} text-sm sm:text-base`} onClick={addFolder}>
            <FolderPlus className="h-4 w-4 mr-1 sm:mr-2" />
            Add Folder
          </Button>
        </div>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-2 sm:mb-4">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* File explorer and editor grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* File explorer */}
        <Card className={`p-2 sm:p-4 ${currentTheme.primary} ${currentTheme.border} ring-1 ring-indigo-500/20`}>
          <h3 className="font-semibold mb-2">File Explorer</h3>
          <div className="space-y-2 max-h-[60vh] overflow-auto">
            {/* Folders */}
            {folders
              .filter((folder) => folder.parentId === currentFolderId && folder.id !== "root")
              .map((folder) => (
                <div key={folder.id} className="flex items-center justify-between p-2 rounded hover:bg-slate-800">
                  <div className="flex items-center cursor-pointer" onClick={() => navigateToFolder(folder.id)}>
                    <Folder className="h-4 w-4 mr-2 text-yellow-500" />
                    <span>{folder.name}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-slate-400 hover:text-red-400"
                    onClick={() => deleteFolder(folder.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}

            {/* Files */}
            {files
              .filter((file) => file.parentId === currentFolderId)
              .map((file) => (
                <div
                  key={file.id}
                  className={`flex items-center justify-between p-2 rounded ${
                    activeFile === file.id ? "bg-slate-800 text-white" : "hover:bg-slate-800 hover:text-white"
                  }`}
                >
                  <div
                    className="flex items-center cursor-pointer flex-1 truncate"
                    onClick={() => setActiveFile(file.id)}
                  >
                    <FileText className="h-4 w-4 mr-2 text-blue-500 flex-shrink-0" />
                    <span className="truncate">{file.name}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-slate-400 hover:text-red-400 flex-shrink-0"
                    onClick={() => deleteFile(file.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
          </div>
        </Card>

        {/* Editor and Preview */}
        <Card
          className={`p-2 sm:p-4 ${currentTheme.primary} ${currentTheme.border} ring-1 ring-indigo-500/20 lg:col-span-3`}
        >
          <Tabs defaultValue="editor" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="editor">Editor</TabsTrigger>
              <TabsTrigger value="preview">Preview</TabsTrigger>
              <TabsTrigger value="output">Output</TabsTrigger>
            </TabsList>

            <TabsContent value="editor">
              <div className="flex items-center justify-between mb-2 sm:mb-4">
                <div className="flex items-center space-x-2">
                  <Button variant="outline" className={`${currentTheme.button} p-1 sm:p-2`} onClick={undo}>
                    <Undo className="h-3 w-3 sm:h-4 sm:w-4" />
                  </Button>
                  <Button variant="outline" className={`${currentTheme.button} p-1 sm:p-2`} onClick={redo}>
                    <Redo className="h-3 w-3 sm:h-4 sm:w-4" />
                  </Button>
                </div>
                <div className="text-xs sm:text-sm opacity-60">Last saved: {lastSaved.toLocaleTimeString()}</div>
              </div>
              <textarea
                value={getCurrentFile()?.content || ""}
                onChange={(e) => updateCurrentFile(e.target.value)}
                className={`w-full h-[40vh] sm:h-[60vh] p-2 sm:p-4 font-mono text-xs sm:text-sm rounded-md ${currentTheme.editor} ${currentTheme.text} 
              resize-none focus:outline-none focus:ring-indigo-500/50 transition-all duration-300`}
                spellCheck="false"
              />
            </TabsContent>

            <TabsContent value="preview">
              <div
                className={`w-full h-[40vh] sm:h-[60vh] p-2 sm:p-4 overflow-auto rounded-md 
              ${currentTheme.preview} transition-all duration-300`}
                dangerouslySetInnerHTML={{ __html: preview }}
              />
            </TabsContent>

            <TabsContent value="output">
              <pre
                className={`w-full h-[40vh] sm:h-[60vh] p-2 sm:p-4 overflow-auto rounded-md 
              ${currentTheme.preview} transition-all duration-300 font-mono text-xs sm:text-sm`}
              >
                {output || "Run your code to see output here"}
              </pre>
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  )
}

export default CodeEditor
