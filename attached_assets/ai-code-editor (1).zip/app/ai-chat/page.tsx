"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Icons } from "@/components/icons"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import axios from "axios"

export default function AIChatPage() {
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<any[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const HUGGINGFACE_API_KEY = process.env.NEXT_PUBLIC_HUGGINGFACE_API_KEY

  useEffect(() => {
    // Add a welcome message when the component mounts
    setMessages([
      {
        id: "welcome",
        sender: "AI Assistant",
        content: "Hello! I'm your AI coding assistant. How can I help you today?",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        avatar: "/placeholder.svg?height=32&width=32",
        isAI: true,
      },
    ])
  }, [])

  const handleSendMessage = async () => {
    if (!message.trim()) return

    const userMessage = {
      id: Date.now().toString(),
      sender: "You",
      content: message,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      avatar: "/placeholder.svg?height=32&width=32",
    }

    setMessages((prev) => [...prev, userMessage])
    setMessage("")

    const aiResponse = await fetchAIResponse(message)
    const aiMessage = {
      id: Date.now().toString() + "-ai",
      sender: "AI Assistant",
      content: aiResponse,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      avatar: "/placeholder.svg?height=32&width=32",
      isAI: true,
    }

    setMessages((prev) => [...prev, aiMessage])
  }

  const fetchAIResponse = async (userMessage: string) => {
    try {
      const response = await axios.post(
        "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.1",
        {
          inputs: `<s>[INST] ${userMessage} [/INST]`,
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${HUGGINGFACE_API_KEY}`,
          },
        },
      )

      const rawOutput = response.data[0]?.generated_text || "I'm not sure how to answer that."
      const answer = rawOutput.split("[/INST]")[1]?.trim() || rawOutput.trim()
      return answer
    } catch (error) {
      console.error("AI response fetch error:", error)
      return "⚠️ Sorry, something went wrong while trying to answer your question."
    }
  }

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const formatCodeBlocks = (content: string) => {
    if (!content.includes("```")) return content

    const parts = content.split("```")
    return (
      <>
        {parts.map((part, i) =>
          i % 2 === 0 ? (
            <span key={i}>{part}</span>
          ) : (
            <pre key={i} className="my-2 rounded-md bg-slate-950 p-3 font-mono text-xs text-slate-200">
              <div className="mb-1 flex items-center justify-between">
                <span className="text-xs text-slate-400">{part.includes("\n") ? part.split("\n")[0] : "code"}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 text-slate-400 hover:text-slate-200"
                  onClick={() => {
                    const code = part.includes("\n") ? part.split("\n").slice(1).join("\n") : part
                    navigator.clipboard.writeText(code)
                  }}
                >
                  <Icons.copy className="h-3 w-3" />
                  <span className="sr-only">Copy code</span>
                </Button>
              </div>
              {part.includes("\n") ? part.split("\n").slice(1).join("\n") : part}
            </pre>
          ),
        )}
      </>
    )
  }

  return (
    <div className="container py-10">
      <h1 className="mb-8 text-2xl font-bold text-white">AI Chat Assistant</h1>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
        <div className="lg:col-span-3">
          <Card className="border-slate-800 bg-slate-900">
            <CardHeader className="border-b border-slate-800">
              <CardTitle className="text-slate-200">Chat with AI</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[60vh] p-4">
                <div className="space-y-4">
                  {messages.map((msg) => (
                    <div key={msg.id} className="flex gap-3">
                      <Avatar className="h-8 w-8 flex-shrink-0">
                        <AvatarImage src={msg.avatar} alt={msg.sender} />
                        <AvatarFallback className={`${msg.isAI ? "bg-emerald-700" : "bg-slate-700"} text-white`}>
                          {msg.sender.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex flex-col">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-slate-200">{msg.sender}</span>
                          <span className="text-xs text-slate-400">{msg.timestamp}</span>
                          {msg.isAI && (
                            <Badge
                              variant="outline"
                              className="border-emerald-800 bg-emerald-900/30 text-xs text-emerald-400"
                            >
                              AI
                            </Badge>
                          )}
                        </div>
                        <div className="text-sm text-slate-300">{formatCodeBlocks(msg.content)}</div>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              <div className="border-t border-slate-800 p-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Ask me anything about coding..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault()
                        handleSendMessage()
                      }
                    }}
                    className="flex-1 bg-slate-800 text-slate-200 placeholder:text-slate-500"
                  />
                  <Button onClick={handleSendMessage} className="bg-emerald-600 text-white hover:bg-emerald-700">
                    <Icons.arrowRight className="h-4 w-4" />
                    <span className="sr-only">Send</span>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1">
          <Card className="border-slate-800 bg-slate-900">
            <CardHeader>
              <CardTitle className="text-slate-200">Suggested Prompts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {[
                "How do I create a React component?",
                "Explain async/await in JavaScript",
                "What's the difference between let and const?",
                "How do I center a div with CSS?",
                "Write a function to reverse a string",
              ].map((prompt, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="w-full justify-start border-slate-700 text-left text-slate-300 hover:bg-slate-800 hover:text-slate-200"
                  onClick={() => {
                    setMessage(prompt)
                  }}
                >
                  {prompt}
                </Button>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
