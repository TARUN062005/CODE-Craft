"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Icons } from "@/components/icons"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProjectCard } from "@/components/dashboard/project-card"
import { AISpotlight } from "@/components/dashboard/ai-spotlight"
import { QuickActions } from "@/components/dashboard/quick-actions"

export default function DashboardPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  // Mock projects data
  const projects = [
    {
      id: "1",
      name: "React Todo App",
      description: "A simple todo application built with React",
      language: "TypeScript",
      lastUpdated: "2023-04-05T14:48:00.000Z",
      starred: true,
      thumbnail: "/placeholder.svg?height=120&width=200",
    },
    {
      id: "2",
      name: "Personal Blog",
      description: "My personal blog built with Next.js",
      language: "JavaScript",
      lastUpdated: "2023-03-28T09:12:00.000Z",
      starred: false,
      thumbnail: "/placeholder.svg?height=120&width=200",
    },
    {
      id: "3",
      name: "E-commerce API",
      description: "RESTful API for an e-commerce platform",
      language: "Python",
      lastUpdated: "2023-04-01T16:30:00.000Z",
      starred: true,
      thumbnail: "/placeholder.svg?height=120&width=200",
    },
    {
      id: "4",
      name: "Weather Dashboard",
      description: "A dashboard to display weather information",
      language: "JavaScript",
      lastUpdated: "2023-04-10T11:20:00.000Z",
      starred: false,
      thumbnail: "/placeholder.svg?height=120&width=200",
    },
    {
      id: "5",
      name: "Portfolio Website",
      description: "My personal portfolio website",
      language: "HTML/CSS",
      lastUpdated: "2023-03-15T08:45:00.000Z",
      starred: false,
      thumbnail: "/placeholder.svg?height=120&width=200",
    },
    {
      id: "6",
      name: "Chat Application",
      description: "Real-time chat application using Socket.io",
      language: "JavaScript",
      lastUpdated: "2023-04-08T13:15:00.000Z",
      starred: true,
      thumbnail: "/placeholder.svg?height=120&width=200",
    },
  ]

  // Simulate loading state
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  const filteredProjects = projects.filter(
    (project) =>
      project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.language.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleProjectClick = (projectId: string) => {
    router.push(`/editor/${projectId}`)
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-background to-background/80">
      <div className="container py-6 space-y-8">
        {/* Header with search and actions */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-3xl font-bold tracking-tight">Projects</h1>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <div className="relative">
              <Icons.search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search projects..."
                className="w-full pl-8 sm:w-64"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Quick Actions Floating Toolbar */}
        <QuickActions />

        {/* AI Spotlight Section */}
        <AISpotlight />

        {/* Projects Tabs */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-4 max-w-md">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="recent">Recent</TabsTrigger>
            <TabsTrigger value="starred">Starred</TabsTrigger>
            <TabsTrigger value="archived">Archived</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-6">
            {isLoading ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Card key={i} className="h-[280px] animate-pulse bg-muted/40" />
                ))}
              </div>
            ) : filteredProjects.length > 0 ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredProjects.map((project) => (
                  <ProjectCard key={project.id} project={project} onClick={() => handleProjectClick(project.id)} />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
                <Icons.folder className="h-10 w-10 text-muted-foreground" />
                <h3 className="mt-4 text-lg font-medium">No projects found</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  {searchQuery ? `No projects matching "${searchQuery}"` : "Get started by creating a new project"}
                </p>
                <Button className="mt-4" onClick={() => router.push("/editor/new")}>
                  <Icons.add className="mr-2 h-4 w-4" />
                  Create New Project
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="recent" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredProjects.slice(0, 3).map((project) => (
                <ProjectCard key={project.id} project={project} onClick={() => handleProjectClick(project.id)} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="starred" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredProjects
                .filter((p) => p.starred)
                .map((project) => (
                  <ProjectCard key={project.id} project={project} onClick={() => handleProjectClick(project.id)} />
                ))}
            </div>
          </TabsContent>

          <TabsContent value="archived" className="mt-6">
            <div className="flex flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
              <Icons.archive className="h-10 w-10 text-muted-foreground" />
              <h3 className="mt-4 text-lg font-medium">No archived projects</h3>
              <p className="mt-2 text-sm text-muted-foreground">You don't have any archived projects yet</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
