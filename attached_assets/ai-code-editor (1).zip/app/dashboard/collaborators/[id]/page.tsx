"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Icons } from "@/components/icons"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { toast } from "@/components/ui/use-toast"

interface CollaboratorsPageProps {
  params: {
    id: string
  }
}

export default function CollaboratorsPage({ params }: CollaboratorsPageProps) {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [role, setRole] = useState("viewer")
  const [isLoading, setIsLoading] = useState(false)

  // Mock project data
  const project = {
    id: params.id,
    name: "React Todo App",
    description: "A simple todo application built with React",
  }

  // Mock collaborators data
  const collaborators = [
    {
      id: "1",
      name: "John Doe",
      email: "john.doe@example.com",
      role: "owner",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "2",
      name: "Jane Smith",
      email: "jane.smith@example.com",
      role: "editor",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: "3",
      name: "Bob Johnson",
      email: "bob.johnson@example.com",
      role: "viewer",
      avatar: "/placeholder.svg?height=40&width=40",
    },
  ]

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!email) {
      toast({
        title: "Error",
        description: "Email is required",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // In a real app, you would call your API to invite a collaborator
      console.log({
        projectId: params.id,
        email,
        role,
      })

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Success",
        description: `Invitation sent to ${email}`,
      })

      setEmail("")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send invitation",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getRoleBadgeColor = (role: string) => {
    const colors: Record<string, string> = {
      owner: "bg-purple-600 text-white",
      editor: "bg-blue-600 text-white",
      viewer: "bg-slate-600 text-white",
    }
    return colors[role] || "bg-slate-600 text-white"
  }

  return (
    <div className="container max-w-4xl py-10">
      <div className="mb-8 flex items-center">
        <Button variant="ghost" onClick={() => router.back()} className="mr-4 text-slate-400 hover:text-slate-200">
          <Icons.chevronLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-white">{project.name}</h1>
          <p className="text-sm text-slate-400">{project.description}</p>
        </div>
      </div>

      <div className="grid gap-6">
        <Card className="border-slate-800 bg-slate-900">
          <CardHeader>
            <CardTitle className="text-slate-200">Invite Collaborators</CardTitle>
            <CardDescription className="text-slate-400">
              Invite team members to collaborate on this project
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleInvite} className="flex flex-col gap-4 sm:flex-row">
              <Input
                placeholder="Email address"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 bg-slate-800 text-slate-200 placeholder:text-slate-500"
              />
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger className="w-full bg-slate-800 text-slate-200 sm:w-40">
                  <SelectValue placeholder="Role" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 text-slate-200">
                  <SelectItem value="viewer">Viewer</SelectItem>
                  <SelectItem value="editor">Editor</SelectItem>
                </SelectContent>
              </Select>
              <Button type="submit" disabled={isLoading} className="bg-emerald-600 text-white hover:bg-emerald-700">
                {isLoading ? (
                  <>
                    <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
                    Inviting...
                  </>
                ) : (
                  <>
                    <Icons.userPlus className="mr-2 h-4 w-4" />
                    Invite
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="border-slate-800 bg-slate-900">
          <CardHeader>
            <CardTitle className="text-slate-200">Collaborators</CardTitle>
            <CardDescription className="text-slate-400">Manage who has access to this project</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {collaborators.map((collaborator) => (
                <div
                  key={collaborator.id}
                  className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950 p-4"
                >
                  <div className="flex items-center gap-4">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={collaborator.avatar} alt={collaborator.name} />
                      <AvatarFallback className="bg-slate-700 text-slate-200">
                        {collaborator.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-slate-200">{collaborator.name}</p>
                      <p className="text-sm text-slate-400">{collaborator.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div
                      className={`rounded-full px-2 py-1 text-xs font-medium ${getRoleBadgeColor(collaborator.role)}`}
                    >
                      {collaborator.role.charAt(0).toUpperCase() + collaborator.role.slice(1)}
                    </div>
                    {collaborator.role !== "owner" && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400">
                            <Icons.ellipsis className="h-4 w-4" />
                            <span className="sr-only">More options</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-slate-900 text-slate-200">
                          <DropdownMenuItem>
                            <Icons.settings className="mr-2 h-4 w-4" />
                            <span>Change Role</span>
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-red-500 focus:text-red-500">
                            <Icons.trash className="mr-2 h-4 w-4" />
                            <span>Remove</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
