"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Icons } from "@/components/icons"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import { useTheme } from "next-themes"

export default function SettingsPage() {
  const [isLoading, setIsLoading] = useState(false)
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  // useEffect only runs on the client, so we can safely use browser APIs
  useEffect(() => {
    setMounted(true)
  }, [])

  const handleSaveSettings = async () => {
    setIsLoading(true)

    try {
      // In a real app, you would call your API to save settings
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Success",
        description: "Settings saved successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save settings",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Avoid rendering with server-side theme to prevent hydration mismatch
  if (!mounted) {
    return null
  }

  return (
    <div className="container max-w-4xl py-10">
      <h1 className="mb-8 text-2xl font-bold text-white">Settings</h1>

      <Tabs defaultValue="account" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-slate-900">
          <TabsTrigger value="account" className="data-[state=active]:bg-slate-800 data-[state=active]:text-white">
            Account
          </TabsTrigger>
          <TabsTrigger value="editor" className="data-[state=active]:bg-slate-800 data-[state=active]:text-white">
            Editor
          </TabsTrigger>
          <TabsTrigger
            value="notifications"
            className="data-[state=active]:bg-slate-800 data-[state=active]:text-white"
          >
            Notifications
          </TabsTrigger>
        </TabsList>

        <TabsContent value="account">
          <Card className="border-slate-800 bg-slate-900">
            <CardHeader>
              <CardTitle className="text-slate-200">Account Settings</CardTitle>
              <CardDescription className="text-slate-400">
                Manage your account information and preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-slate-200">
                  Name
                </Label>
                <Input id="name" defaultValue="John Doe" className="bg-slate-800 text-slate-200" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-200">
                  Email
                </Label>
                <Input id="email" defaultValue="john.doe@example.com" className="bg-slate-800 text-slate-200" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-200">
                  Password
                </Label>
                <Input id="password" type="password" defaultValue="********" className="bg-slate-800 text-slate-200" />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button
                onClick={handleSaveSettings}
                disabled={isLoading}
                className="bg-emerald-600 text-white hover:bg-emerald-700"
              >
                {isLoading ? (
                  <>
                    <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="editor">
          <Card className="border-slate-800 bg-slate-900">
            <CardHeader>
              <CardTitle className="text-slate-200">Editor Settings</CardTitle>
              <CardDescription className="text-slate-400">Customize your coding environment</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="theme" className="text-slate-200">
                  Theme
                </Label>
                <Select value={theme} onValueChange={setTheme}>
                  <SelectTrigger className="bg-slate-800 text-slate-200">
                    <SelectValue placeholder="Select a theme" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 text-slate-200">
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="system">System</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="font-size" className="text-slate-200">
                  Font Size
                </Label>
                <Select defaultValue="14">
                  <SelectTrigger className="bg-slate-800 text-slate-200">
                    <SelectValue placeholder="Select font size" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 text-slate-200">
                    <SelectItem value="12">12px</SelectItem>
                    <SelectItem value="14">14px</SelectItem>
                    <SelectItem value="16">16px</SelectItem>
                    <SelectItem value="18">18px</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="line-numbers" className="text-slate-200">
                  Show Line Numbers
                </Label>
                <Switch id="line-numbers" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="word-wrap" className="text-slate-200">
                  Word Wrap
                </Label>
                <Switch id="word-wrap" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="auto-save" className="text-slate-200">
                  Auto Save
                </Label>
                <Switch id="auto-save" defaultChecked />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button
                onClick={handleSaveSettings}
                disabled={isLoading}
                className="bg-emerald-600 text-white hover:bg-emerald-700"
              >
                {isLoading ? (
                  <>
                    <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card className="border-slate-800 bg-slate-900">
            <CardHeader>
              <CardTitle className="text-slate-200">Notification Settings</CardTitle>
              <CardDescription className="text-slate-400">
                Configure how and when you receive notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <Label htmlFor="email-notifications" className="text-slate-200">
                  Email Notifications
                </Label>
                <Switch id="email-notifications" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="push-notifications" className="text-slate-200">
                  Push Notifications
                </Label>
                <Switch id="push-notifications" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="collaboration-invites" className="text-slate-200">
                  Collaboration Invites
                </Label>
                <Switch id="collaboration-invites" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="project-updates" className="text-slate-200">
                  Project Updates
                </Label>
                <Switch id="project-updates" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="security-alerts" className="text-slate-200">
                  Security Alerts
                </Label>
                <Switch id="security-alerts" defaultChecked />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button
                onClick={handleSaveSettings}
                disabled={isLoading}
                className="bg-emerald-600 text-white hover:bg-emerald-700"
              >
                {isLoading ? (
                  <>
                    <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
