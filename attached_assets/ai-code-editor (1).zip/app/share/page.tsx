"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download, Copy } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import Link from "next/link"

export default function SharePage() {
  const searchParams = useSearchParams()
  const [fileName, setFileName] = useState("")
  const [content, setContent] = useState("")
  const [error, setError] = useState("")

  useEffect(() => {
    try {
      const codeParam = searchParams.get("code")
      if (codeParam) {
        const decodedData = JSON.parse(decodeURIComponent(codeParam))
        setFileName(decodedData.fileName || "Shared Code")
        setContent(decodedData.content || "")
      } else {
        setError("No code found in the URL")
      }
    } catch (err) {
      setError("Failed to parse shared code")
      console.error(err)
    }
  }, [searchParams])

  const copyToClipboard = () => {
    navigator.clipboard
      .writeText(content)
      .then(() => {
        toast({
          title: "Copied!",
          description: "Code copied to clipboard",
        })
      })
      .catch(() => {
        setError("Failed to copy code")
      })
  }

  const downloadCode = () => {
    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = fileName
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen p-4 sm:p-6 bg-slate-100 dark:bg-slate-900">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Shared Code: {fileName}</h1>
          <div className="flex gap-2">
            <Button variant="outline" onClick={copyToClipboard}>
              <Copy className="h-4 w-4 mr-2" />
              Copy
            </Button>
            <Button variant="outline" onClick={downloadCode}>
              <Download className="h-4 w-4 mr-2" />
              Download
            </Button>
            <Link href="/code-editor">
              <Button>Open in Editor</Button>
            </Link>
          </div>
        </div>

        {error ? (
          <Card className="p-6 bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800">
            <p className="text-red-700 dark:text-red-400">{error}</p>
          </Card>
        ) : (
          <Card className="p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <pre className="overflow-auto p-4 bg-slate-100 dark:bg-slate-900 rounded-md text-sm font-mono">
              {content}
            </pre>
          </Card>
        )}
      </div>
    </div>
  )
}
